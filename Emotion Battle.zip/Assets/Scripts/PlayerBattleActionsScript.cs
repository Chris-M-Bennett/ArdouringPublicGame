﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerBattleActionsScript : MonoBehaviour
{
    States ["Neutral", "General", "Persuade", "Argue", "Items"]
    //Game Objects
    [SerializeField] private Button generalButton;
    [SerializeField] private Button persuadeButton;
    [SerializeField] private Button argueButton;
    [SerializeField] private Button itemsButton;
    [SerializeField] private Button checkButton;
    [SerializeField] private Button giftButton;
    [SerializeField] private Button runButton;
    [SerializeField] private Button endBattleButton;
    [SerializeField] private Button varyingButton;
    [SerializeField] private Button thankButton;
    [SerializeField] private Button onTopicButton;
    [SerializeField] private Button ethosButton;
    [SerializeField] private Panel generalPanel;
    [SerializeField] private Panel persuadePanel;
    [SerializeField] private Panel arguePanel;
    [SerializeField] private Panel itemsPanel;
    [SerializeField] private Panel[] panelsArray;

    void Start()
    {
        panelsArray[0] = generalPanel;
        panelsArray[1] = persuadePanel;
        panelsArray[2] = arguePanel;
        panelsArray[3] = itemsPanel;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void GetButtonDown()
    {
        if (persuadeButton.gameObject.tag == "BattleOption"){
            ClosePanels();
        }
        if (button == generalButton){
            generalPanel.enabled = true;
            setState("General");
        }else if (button == persuadeButton){
            persuadePanel.enabled = true;
            setState("Persuade");
        }else if (button == argueButton){
            arguePanel.enabled = true;
        }else if (button == itemsButton){
            itemsPanel.enabled = true;
            setState("Argue");
        }else if (button == checkButton){
           
        }
    }


    void ClosePanels()
    {
        for (int i; i<panelsArray.Length; i++){
            panelsArray[i].enabled = false;
        }
    }
}
